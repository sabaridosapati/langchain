from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

load_dotenv()

model = ChatGoogleGenerativeAI(model="gemini-2.5-flash")

# chat history
chat_history = [
    HumanMessage(content="Can you book a flight from Hyderabad to Delhi for tomorrow morning?"),
    AIMessage(content="Sure! I found several flights from Hyderabad to Delhi tomorrow morning. "
                      "The earliest is at 6:10 AM with Indigo. Would you like me to proceed?")
]

# chat template and use messageplaceholder to insert prior chat history
chat_template = ChatPromptTemplate(
    messages=[
        ('system','You are a helpful customer support agent'),
        MessagesPlaceholder(variable_name='chat_history'),
        ('human', '{query}')
    ]
)

# create prompt
prompt = chat_template.invoke({
    'chat_history': chat_history,
    'query': 'How could I book?'
})

print(prompt)

# call Gemini
result = model.invoke(prompt)
print("Gemini Response:", result.content)
