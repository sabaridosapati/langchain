from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

load_dotenv()

model = ChatGoogleGenerativeAI(model="gemini-2.5-flash")

context="policy says an employee can take 5 days leave a an year"
question="how many days an employee can take leaves in an year"

promptstatement = f"Use the following context to answer the question:Context: {context}  Question: {question} Answer:",context,question

print(promptstatement)

result = model.invoke(promptstatement)

print(result.content)


